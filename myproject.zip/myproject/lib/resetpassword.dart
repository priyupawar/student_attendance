import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ResetPassword extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _ResetPassword();
  }
}

String line2;

class _ResetPassword extends State<ResetPassword> {
  SharedPreferences prefs;
  @override
  void initState() {
    SharedPreferences.getInstance().then((SharedPreferences sp) {
      setState(() {
        line2 = sp.getString('line2');
        //path = prefs.getString('path');
      });
    });
    super.initState();
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  String name;
  String password;
  String retype;
  bool match = false;
  Future resetpass(String userid, String password) async {
    String json = '{"userid":"' + userid + '","password":"' + password + '"}';
    String url = 'http://167.114.145.37:3000/ResetPassword';
    Map<String, String> headers = {
      // "Content-Type": "application/x-www-form-urlencoded"
      "Content-type": "application/json"
    };
    var response = await http.post(url, headers: headers, body: json);
    print(response.body);
    if (response.body != '') {
      return 'Sucess';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.teal,
        appBar: AppBar(
          title: Text(line2),
        ),
        key: _scaffoldKey,
        body: Center(
          child: Padding(
              padding: EdgeInsets.all(10),
              child: SingleChildScrollView(
                  child: Card(
                      child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Icon(Icons.perm_identity, size: 100, color: Colors.teal),
                  Padding(
                      padding: EdgeInsets.only(bottom: 10, top: 0),
                      child: Text(
                        'Reset Password',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: Colors.teal),
                      )),
                  Padding(
                      padding: EdgeInsets.all(10),
                      child: TextFormField(
                        onChanged: (String value) {
                          setState(() {
                            name = value;
                          });
                        },
                        decoration: InputDecoration(
                            enabledBorder: const OutlineInputBorder(
                              borderSide: const BorderSide(
                                  color: Colors.teal, width: 0.0),
                            ),
                            focusedBorder: const OutlineInputBorder(
                              borderSide: const BorderSide(
                                  color: Colors.teal, width: 0.0),
                            ),
                            labelText: 'Username',
                            labelStyle: TextStyle(color: Colors.teal)),
                      )),
                  Padding(
                      padding: EdgeInsets.all(10),
                      child: TextFormField(
                        obscureText: true,
                        onChanged: (String value) {
                          setState(() {
                            password = value;
                          });
                        },
                        decoration: InputDecoration(
                            enabledBorder: const OutlineInputBorder(
                              borderSide: const BorderSide(
                                  color: Colors.teal, width: 0.0),
                            ),
                            focusedBorder: const OutlineInputBorder(
                              borderSide: const BorderSide(
                                  color: Colors.teal, width: 0.0),
                            ),
                            labelText: 'Password',
                            labelStyle: TextStyle(color: Colors.teal)),
                      )),
                  Padding(
                      padding: EdgeInsets.all(10),
                      child: TextFormField(
                        obscureText: true,
                        onChanged: (String value) {
                          setState(() {
                            retype = value;

                            if (retype == password) {
                              match = false;
                            } else {
                              match = true;
                            }
                          });
                        },
                        decoration: InputDecoration(
                            enabledBorder: const OutlineInputBorder(
                              borderSide: const BorderSide(
                                  color: Colors.teal, width: 0.0),
                            ),
                            focusedBorder: const OutlineInputBorder(
                              borderSide: const BorderSide(
                                  color: Colors.teal, width: 0.0),
                            ),
                            labelText: 'Retype Password',
                            labelStyle: TextStyle(color: Colors.teal)),
                      )),
                  match
                      ? Text('Password not matched',
                          style: TextStyle(color: Colors.red))
                      : Text(''),
                  SizedBox(
                      width: double.infinity,
                      height: 80,
                      child: Padding(
                          padding: EdgeInsets.all(10),
                          child: RaisedButton(
                            elevation: 20,
                            color: Colors.white,
                            child: Text('Submit',
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.teal,
                                )),
                            onPressed: () {
                              var msg = resetpass(name, password);
                              if (msg.toString() != '') {
                                final snackBar = SnackBar(
                                  content: Text('Password Reset Sucessfully'),
                                );
                                _scaffoldKey.currentState
                                    .showSnackBar(snackBar);
                              }
                              // Navigator.pushReplacement(
                              //   context,
                              //   MaterialPageRoute(builder: (context) => MainPage()),
                              // );
                            },
                          )))
                ],
              )))),
        ));
  }
}
