import 'dart:convert';

import "package:flutter/material.dart";
import 'package:myproject/detailform.dart';
import 'package:myproject/sidenav.dart';
import 'package:http/http.dart' as http;
import 'package:page_transition/page_transition.dart';
import 'package:shared_preferences/shared_preferences.dart';
//import 'package:flutter_slidable/flutter_slidable.dart';

String path;
String data;
String name;

class ReportList extends StatefulWidget {
  final name;
  // final type;
  ReportList(this.name);
  @override
  State<StatefulWidget> createState() {
    return _ReportList();
  }
}

Future getReport(String att, String page) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  //userid = prefs.getString('username');
  path = prefs.getString('path');
  String json = '{"AttType":"' + att + '","PageType":"' + page + '"}';
  String url = '' + path + '/GetReportMainPage';
  print(json);
  Map<String, String> headers = {
    // "Content-Type": "application/x-www-form-urlencoded"
    "Content-type": "application/json"
  };
  var response = await http.post(url, headers: headers, body: json);
  data = response.body;
  print(data);
}

class _ReportList extends State<ReportList> {
  @override
  void initState() {
    setState(() {
      name = widget.name;
      // getReport(widget.name, 'ReportList');
    });
    super.initState();
  }

  // ReportList(this.name, this.type);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Report List'),
        ),
        //body:
        // drawer: SideNav(),
        body: list(context));
  }
}

Widget list(BuildContext context) {
  return FutureBuilder(
    builder: (BuildContext context, snapshot) {
      // print(snapshot);
      if (snapshot.connectionState == ConnectionState.done) {
        List reportDetails = jsonDecode(data);

        return ListView.builder(
          itemCount: reportDetails.length,
          itemBuilder: (BuildContext content, int index) {
            String name = reportDetails[index]['RPT_NAME'];
            String id = reportDetails[index]['TRANSID'];
            String desc = reportDetails[index]['RPT_DESC'];
            int color = int.parse(reportDetails[index]['COLOR']);
            // var hex = new Color(color.value);
            int icon = int.parse(reportDetails[index]['ICON']);
            // return ContactListTile(name,intime,outtime);
            return SizedBox(
                height: 80,
                child: RaisedButton(
                  // padding: EdgeInsets.only(top:10,bottom:10),
                  elevation: 15,
                  color: Colors.white,
                  onPressed: () {
                    Navigator.push(
                      context,
                      PageTransition(
                          type: PageTransitionType.downToUp,
                          child: DetailForm(name, id)),
                    );
                  },

                  child: Card(
                    child: ListTile(
                      leading: Icon(
                        IconData(icon, fontFamily: 'MaterialIcons'),
                        color: Colors.teal,
                        size: 36.0,
                      ),
                      title: Text(
                        name,
                        style: TextStyle(fontSize: 18.0, color: Color(color)),
                      ),
                      subtitle: Text(desc),
                    ),
                  ),
                ));
          },
        );
      } else {
        return Center(
          child: CircularProgressIndicator(),
        );
      }
    },
    future: getReport(name, 'ReportList'),
  );
}
