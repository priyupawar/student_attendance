import 'package:flutter/material.dart';
import 'package:myproject/sidenav.dart';

class BottomNav extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _BottomNav();
  }
}

class _BottomNav extends State<BottomNav> {
  static const _kBottmonNavBarItems = <BottomNavigationBarItem>[
    BottomNavigationBarItem(
      backgroundColor: Colors.teal,
      icon: Icon(Icons.add_circle),
      title: Text('Add'),
    ),
    BottomNavigationBarItem(
      backgroundColor: Colors.lightGreen,
      icon: Icon(Icons.edit),
      title: Text('Edit'),
    ),
    BottomNavigationBarItem(
      backgroundColor: Colors.green,
      icon: Icon(Icons.cancel),
      title: Text('Cancel'),
    ),
    BottomNavigationBarItem(
      backgroundColor: Colors.green,
      icon: Icon(Icons.delete),
      title: Text('Delete'),
    ),
  ];

  int _currentTabIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('More'),
      ),
      drawer: SideNav(),
      body: IndexedStack(
        children: <Widget>[
          Master(),
          Master(),
          Master(),
        ],
        index: _currentTabIndex,
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: _kBottmonNavBarItems,
        currentIndex: _currentTabIndex,
        type: BottomNavigationBarType.shifting,
        onTap: (int index) {
          setState(() => this._currentTabIndex = index);
        },
      ),
    );
  }
}

class Master extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _Master();
  }
}

final List<String> _listViewData = [
  "Inducesmile.com",
  "Flutter Dev",
  "Android Dev",
];

List<ExpansionTile> _listOfExpansions = List<ExpansionTile>.generate(
    2,
    (i) => ExpansionTile(
          title: Text("Expansion $i"),
          children: _listViewData
              .map((data) => ListTile(
                    leading: Icon(Icons.person),
                    title: Text(data),
                    subtitle: Text("a subtitle here"),
                  ))
              .toList(),
        ));

class _Master extends State<Master> {
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.all(8.0),
      children:
          _listOfExpansions.map((expansionTile) => expansionTile).toList(),
    );
    // return ListView.builder(
    //     itemCount: data.length,
    //     itemBuilder: (BuildContext content, int index) {
    //       return GestureDetector(
    //           onTap: () {
    //             print('');
    //           },
    //           child: Card(
    //               child: ListTile(
    //             leading: Icon(Icons.ac_unit),
    //             title: EntryItem(data[index]),
    //             //subtitle: Text('hello'),
    //           )));
    //       //itemBuilder: (BuildContext context, int index) => Card(EntryItem(data[index])),
    //     });
  }
}

class Entry {
  const Entry(this.title, [this.children = const <Entry>[]]);
  final String title;
  final List<Entry> children;
}

const List<Entry> data = <Entry>[
  Entry(
    'Masters',
    <Entry>[
      Entry(
        'Change Password',
        // <Entry>[
        //   Entry('Item A0.1'),
        //   Entry('Item A0.2'),
        // ],
      ),
      Entry('Edit Profile'),
      //Entry('Section A2'),
    ],
  ),
  Entry(
    'Transaction',
    <Entry>[
      Entry('Section B0'),
      Entry('Section B1'),
    ],
  ),
];
// Data to display.
// const List<Entry> data = <Entry>[
//   Entry(
//     'MASTER',
//     <Entry>[
//       Entry('EMPLOYEE DATA'),
//       Entry('STUDENT DATA'),
//       Entry('SHIFT DATA'),
//     ],
//   ),
//   Entry(
//     'TRANSACTION',
//     <Entry>[
//       Entry('Manual Attendance Update'),
//       Entry('ReCalculate Attendance'),
//     ],
//   ),
//   Entry(
//     'REPORT',
//     <Entry>[
//       Entry(
//         'EMPLOYEE',
//         <Entry>[
//           Entry('Present'),
//           Entry('Absent'),
//           Entry('Latecomers'),
//           Entry('Missing Punch'),
//           Entry('Absent'),
//         ]),
//         Entry(
//           'STUDENTS',
//           <Entry>[
//             Entry('Present'),
//             Entry('Absent'),
//             Entry('Latecomers'),
//             Entry('Missing Punch'),
//             Entry('Absent'),
//           ],
//         ),
//       ),
//     ],
//   ),
//];

// Displays one Entry. If the entry has children then it's displayed
// with an ExpansionTile.
class EntryItem extends StatelessWidget {
  const EntryItem(this.entry);

  final Entry entry;

  Widget _buildTiles(Entry root) {
    if (root.children.isEmpty) return ListTile(title: Text(root.title));
    return ExpansionTile(
      key: PageStorageKey<Entry>(root),
      title: Text(root.title),
      children: root.children.map(_buildTiles).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return _buildTiles(entry);
  }
}
