import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:myproject/groupsms.dart';
import 'package:myproject/reportlist.dart';
import 'package:myproject/sidenav.dart';
import 'package:page_transition/page_transition.dart';
import 'package:shared_preferences/shared_preferences.dart';

//import 'package:esc_pos_printer/esc_pos_printer.dart';
//import 'package:image/image.dart';

String userid;

String password;
String ip;
int port;
String msg;

class MainPage extends StatefulWidget {
  final line2;
  MainPage(this.line2);
  @override
  State<StatefulWidget> createState() {
    return _MainPage();
  }
}

String path;
String data;
void getUser() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  userid = prefs.getString('username');
  path = prefs.getString('path');
  // print('path' + path);
  password = prefs.getString('password');
}

void logout() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  prefs.remove('username');
  prefs.remove('password');
  prefs.setBool('isLoggedIn', false);
}

Future getReport(String att, String page) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  //userid = prefs.getString('username');
  path = prefs.getString('path');
  String json = '{"AttType":"' + att + '","PageType":"' + page + '"}';
  String url = '' + path + '/GetReportMainPage';
  //print(json);
  Map<String, String> headers = {
    // "Content-Type": "application/x-www-form-urlencoded"
    "Content-type": "application/json"
  };
  var response = await http.post(url, headers: headers, body: json);
  data = response.body;
  //print(data);
  // Navigator.push(
  //     context,
  //     PageTransition(
  //         type: PageTransitionType.leftToRight,
  //         child: ReportList(response.body)));
}

class _MainPage extends State<MainPage> {
  Future testprint() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    path = prefs.getString('path');
    print(path);
    var response = await http.get('' + path + '/testprint');
    print(response.body);
    var res = jsonDecode(response.body);
    ip = res[0]['id'];

    port = int.parse(res[0]['port']);
    msg = res[0]['msg'];
  }

  Future<void> _optionsDialogBox() {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: new SingleChildScrollView(
              child: new ListBody(
                children: <Widget>[
                  GestureDetector(
                    child: new Text('Take a picture'),
                    // onTap: openCamera,
                  ),
                  Padding(
                    padding: EdgeInsets.all(8.0),
                  ),
                  GestureDetector(
                    child: new Text('Select from gallery'),
                    //onTap: openGallery,
                  ),
                ],
              ),
            ),
          );
        });
  }

  // static const _kBottmonNavBarItems = <BottomNavigationBarItem>[
  //   BottomNavigationBarItem(
  //     backgroundColor: Colors.blue,
  //     icon: Icon(Icons.library_books),
  //     title: Text('Basics'),
  //   ),
  //   BottomNavigationBarItem(
  //     backgroundColor: Colors.blueAccent,
  //     icon: Icon(Icons.insert_chart),
  //     title: Text('Advanced'),
  //   ),
  //   BottomNavigationBarItem(
  //     backgroundColor: Colors.indigo,
  //     icon: Icon(Icons.star),
  //     title: Text('Bookmarks'),
  //   ),
  // ];

  // int _currentTabIndex = 0;

  @override
  void initState() {
    setState(() {
      getUser();
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    //List reportDetails = jsonDecode(data);
    return Scaffold(
        // backgroundColor: Colors.black,
        // floatingActionButton: Icon(Icons.camera_alt),
        // floatingActionButtonLocation:FloatingActionButtonLocation.endTop,
        appBar: AppBar(
          title: Text(widget.line2),
          // actions: <Widget>[
          //   FlatButton(
          //     textColor: Colors.white,
          //     onPressed: () {
          //       _optionsDialogBox();
          //     },
          //     child: Icon(Icons.add_a_photo),
          //     shape: CircleBorder(side: BorderSide(color: Colors.transparent)),
          //   ),
          // ],
        ),
        drawer: SideNav(),
        body: Padding(
            padding: EdgeInsets.all(10),
            child: Card(
              child: SingleChildScrollView(
                  child: Column(children: <Widget>[
                ClipRRect(
                  borderRadius: new BorderRadius.only(
                      topLeft: Radius.circular(8.0),
                      topRight: Radius.circular(8.0)),
                  child: Image.asset('assets/school.jpeg'),
                ),
                SizedBox(
                    width: double.infinity,
                    height: MediaQuery.of(context).size.height,
                    child: list(context)),
                // Column(
                //   children: <Widget>[
                //     Padding(
                //       padding: EdgeInsets.all(10),
                //       child: GridView.count(
                //         shrinkWrap: true,
                //         crossAxisCount: 2,
                //         children: <Widget>[
                //           SizedBox(
                //             width: double.infinity,
                //             // height: screenHeight(context,dividedBy: 7),
                //             height: double.infinity,
                //             child: Padding(
                //                 padding: EdgeInsets.all(5),
                //                 child: RaisedButton(
                //                     color: Colors.white,
                //                     elevation: 16,
                //                     //padding: EdgeInsets.all(10.0),
                //                     onPressed: () {
                //                       // Navigator.push(context,MaterialPageRoute(builder: (context) => StudentForm()),);
                //                       getReport('Students');
                //                     },
                //                     child: Column(
                //                       mainAxisAlignment:
                //                           MainAxisAlignment.center,
                //                       children: <Widget>[
                //                         Icon(
                //                           Icons.perm_identity,
                //                           color: Colors.teal,
                //                           size: 50,
                //                         ),
                //                         Text(
                //                           'Students',
                //                           style: TextStyle(
                //                               color: Colors.teal,
                //                               fontSize: 20.0),
                //                         )
                //                       ],
                //                     ))),
                //           ),
                //           SizedBox(
                //             width: double.infinity,
                //             height: double.infinity,
                //             child: Padding(
                //                 padding: EdgeInsets.all(5),
                //                 child: RaisedButton(
                //                     color: Colors.white,
                //                     elevation: 16,
                //                     //padding: EdgeInsets.all(10.0),
                //                     onPressed: () {
                //                       //  Navigator.push(context,MaterialPageRoute(builder: (context) => EmpForm()),);

                //                       getReport('Staff');
                //                     },
                //                     child: Column(
                //                       mainAxisAlignment:
                //                           MainAxisAlignment.center,
                //                       children: <Widget>[
                //                         Icon(
                //                           Icons.account_circle,
                //                           color: Colors.teal,
                //                           size: 50,
                //                         ),
                //                         Text(
                //                           'Employees',
                //                           style: TextStyle(
                //                               color: Colors.teal,
                //                               fontSize: 20.0),
                //                         )
                //                       ],
                //                     ))),
                //           ),
                //         ],
                //       ),
                //     ),
                //     SizedBox(
                //       width: double.infinity,
                //       height: 200,
                //       child: Padding(
                //           padding: EdgeInsets.all(10),
                //           child: RaisedButton(
                //               color: Colors.white,
                //               elevation: 16,
                //               onPressed: () {
                //                 Navigator.push(
                //                   context,
                //                   MaterialPageRoute(
                //                       builder: (context) => GroupSms()),
                //                 );

                //                 //getReport('Staff');
                //               },
                //               child: Center(
                //                   child: Column(
                //                 mainAxisAlignment: MainAxisAlignment.center,
                //                 children: <Widget>[
                //                   Icon(
                //                     Icons.group,
                //                     color: Colors.teal,
                //                     size: 50,
                //                   ),
                //                   Text(
                //                     'Group SMS',
                //                     style: TextStyle(
                //                         color: Colors.teal, fontSize: 20.0),
                //                   )
                //                 ],
                //               )))),
                //     ),
                //   ],
                // )
              ])),
            )));
  }
}

Widget list(BuildContext context) {
  return FutureBuilder(
    builder: (BuildContext context, snapshot) {
      // print(snapshot);
      if (snapshot.connectionState == ConnectionState.done) {
        List reportDetails = jsonDecode(data);
        return ListView.builder(
          itemCount: reportDetails.length,
          itemBuilder: (BuildContext content, int index) {
            String name = reportDetails[index]['RPT_NAME'];
            String id = reportDetails[index]['TRANSID'];
            String desc = reportDetails[index]['RPT_DESC'];
            int color = int.parse(reportDetails[index]['COLOR']);
            // var hex = new Color(color.value);
            int icon = int.parse(reportDetails[index]['ICON']);
            // return ContactListTile(name,intime,outtime);
            return SizedBox(
                height: 80,
                child: RaisedButton(
                  // padding: EdgeInsets.only(top:10,bottom:10),
                  elevation: 15,
                  color: Colors.white,
                  onPressed: () {
                    Navigator.push(
                      context,
                      PageTransition(
                          type: PageTransitionType.downToUp,
                          child: ReportList(name)),
                    );
                  },

                  child: Card(
                    child: ListTile(
                      leading: Icon(
                        IconData(icon, fontFamily: 'MaterialIcons'),
                        color: Colors.teal,
                        size: 36.0,
                      ),
                      title: Text(
                        name,
                        style: TextStyle(fontSize: 18.0, color: Color(color)),
                      ),
                      subtitle: Text(desc),
                    ),
                  ),
                ));
          },
        );
      } else {
        return Container(
          padding: EdgeInsets.all(10),
          alignment: Alignment.topCenter,
          child: CircularProgressIndicator(),
        );
      }
    },
    future: getReport('null', 'MainPage'),
  );
}

// Future printPage() {
//   Printer.connect(ip, port: port).then((printer) {
//     printer.println(
//         'Regular: aA bB cC dD eE fF gG hH iI jJ kK lL mM nN oO pP qQ rR sS tT uU vV wW xX yY zZ');
//     printer.println('Special 1: àÀ èÈ éÉ ûÛ üÜ çÇ ôÔ',
//         styles: PosStyles(codeTable: PosCodeTable.westEur));
//     printer.println('Special 2: blåbærgrød',
//         styles: PosStyles(codeTable: PosCodeTable.westEur));

//     printer.println('Bold text', styles: PosStyles(bold: true));
//     printer.println('Reverse text', styles: PosStyles(reverse: true));
//     printer.println('Underlined text',
//         styles: PosStyles(underline: true), linesAfter: 1);
//     printer.println('Align left', styles: PosStyles(align: PosTextAlign.left));
//     printer.println('Align center',
//         styles: PosStyles(align: PosTextAlign.center));
//     printer.println('Align right',
//         styles: PosStyles(align: PosTextAlign.right), linesAfter: 1);
//     printer.printRow([
//       PosColumn(
//         text: 'col3',
//         width: 3,
//         styles: PosStyles(align: PosTextAlign.center, underline: true),
//       ),
//       PosColumn(
//         text: 'col6',
//         width: 6,
//         styles: PosStyles(align: PosTextAlign.center, underline: true),
//       ),
//       PosColumn(
//         text: 'col3',
//         width: 3,
//         styles: PosStyles(align: PosTextAlign.center, underline: true),
//       ),
//     ]);
//     printer.println('Text size 200%',
//         styles: PosStyles(
//           height: PosTextSize.size2,
//           width: PosTextSize.size2,
//         ));

//     // Print image
//     // const String filename = 'assets/school.jpeg';
//     // final Image image = decodeImage(File(filename).readAsBytesSync());
//     // printer.printImage(image);
//     // // Print image using an alternative (obsolette) command
//     // // printer.printImageRaster(image);

//     // Print barcode
//     final List<int> barData = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 4];
//     printer.printBarcode(Barcode.upcA(barData));

//     // Print mixed (chinese + latin) text. Only for printers supporting Kanji mode
//     // printer.println(
//     //   'hello ! 中文字 # world @ éphémère &',
//     //   styles: PosStyles(codeTable: PosCodeTable.westEur),
//     // );
//     printer.println(msg);
//     print(msg);
//     printer.cut();
//     printer.disconnect();
//   });
// }
