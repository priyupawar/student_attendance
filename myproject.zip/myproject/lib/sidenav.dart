import 'package:flutter/material.dart';
import 'package:myproject/moredrawer.dart';
import 'package:myproject/resetpassword.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'authform.dart';
import 'groupsms.dart';

String userid = '';

String password;
String path;

Future getUser() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();

  // userid = prefs.getString('username');

  path = prefs.getString('path');

  password = prefs.getString('password');
}

class SideNav extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _SideNav();
  }
}

class _SideNav extends State<SideNav> with SingleTickerProviderStateMixin {
  SharedPreferences prefs;

  TabController _tabController;

  static const _kTabPages = <Widget>[
    Center(child: Icon(Icons.cloud, size: 64.0, color: Colors.teal)),
    Center(child: Icon(Icons.alarm, size: 64.0, color: Colors.cyan)),
    Center(child: Icon(Icons.forum, size: 64.0, color: Colors.blue)),
  ];
  // static const _kTabs = <Tab>[
  //   Tab(icon: Icon(Icons.cloud), text: 'Tab1'),
  //   Tab(icon: Icon(Icons.alarm), text: 'Tab2'),
  //   Tab(icon: Icon(Icons.forum), text: 'Tab3'),
  // ];

  void logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('username');
    prefs.remove('password');
    prefs.setBool('isLoggedIn', false);
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: _kTabPages.length, vsync: this,
      //vsync: this,
    );
    SharedPreferences.getInstance().then((SharedPreferences sp) {
      setState(() {
        userid = sp.getString('username');
        //path = prefs.getString('path');
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.teal,
            ),
            child: Profile(),
          ),
          // ListTile(
          //   leading: Icon(Icons.perm_identity),
          //   title: Text('More'),
          //   onTap: () {
          //     // getReport('Students');
          //     Navigator.push(
          //       context,
          //       MaterialPageRoute(builder: (context) => BottomNav()),
          //     );
          //   },
          // ),

          ListTile(
            leading: Icon(Icons.group),
            title: Text('Group Messages'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => GroupSms()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text('Reset Password'),
            onTap: () {
              //resetpass(userid,password);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ResetPassword()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.power_settings_new),
            title: Text('Logout'),
            onTap: () {
              logout();
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => AuthForm()),
              );
            },
          ),
        ],
      ),
    );
  }
}

class Profile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
        child: Column(
      children: <Widget>[
        CircleAvatar(
          // child: Text('U',style: TextStyle(fontSize: 30),),
          child: Icon(Icons.account_balance, size: 50),
          radius: 50,
          backgroundColor: Colors.white,
        ),
        Text(
          userid.toUpperCase(),
          style: TextStyle(
            fontSize: 20,
            color: Colors.white,
          ),
        )
      ],
    ));
  }
}

//         ListTile(
//           leading: Icon(Icons.edit),
//           title: Text('Edit Profile'),
//         ),
//         ListTile(
//           leading: Icon(Icons.perm_identity),
//           title: Text('Students'),
//           onTap: (){
//              getReport('Students');
//           },
//         ),
//         ListTile(
//           leading: Icon(Icons.account_circle),
//           title: Text('Teacher'),
//           onTap: (){
//              getReport('Staff');
//           },
//         ),
//         ListTile(
//           leading: Icon(Icons.group),
//           title: Text('Group Messages'),
//           onTap: (){
//             Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                                 builder: (context) => GroupSms()),
//                           );
//           },
//         ),

//         ListTile(
//           leading: Icon(Icons.settings),
//           title: Text('Reset Password'),
//           onTap: (){
//             //resetpass(userid,password);
//             Navigator.push(
//                       context,
//                       MaterialPageRoute(builder: (context) => ResetPassword()),
//                     );
//           },
//         ),
//         ListTile(
//           leading: Icon(Icons.power_settings_new),
//           title: Text('Logout'),
//           onTap: (){
//             logout();
//             Navigator.pushReplacement(
//   context,
//   MaterialPageRoute(builder: (context) => AuthForm()),
// );
//           },
//         ),
//         ListTile(
//           leading: Icon(Icons.power_settings_new),
//           title: Text('Print'),
//           onTap: (){
//           printPage();
//           },
//         ),
//
