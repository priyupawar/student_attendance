import 'dart:async';
import 'package:flutter/material.dart';
//import 'package:flare_flutter/flare_actor.dart';
import "package:flare_flutter/flare_actor.dart";
import 'package:http/http.dart' as http;
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:myproject/splashscreen.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

bool remember = true;
String name;
String pass;
final _name = TextEditingController();
final _pass = TextEditingController();

class AuthForm extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _AuthForm();
  }
}

class _AuthForm extends State<AuthForm> {
  @override
  Widget build(BuildContext context) {
    return LoginForm();
  }
}

void loginUser(username, password, path, line1, line2) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  prefs.setBool('isLoggedIn', true);
  prefs.setString('username', username);
  prefs.setString('password', password);
  prefs.setString('path', path);
  prefs.setString('line1', line1);
  prefs.setString('line2', line2);
  prefs.setBool('remember', remember);
}

void getRemember() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  remember = prefs.getBool('remember');
  if (remember == true) {
    //remember = true;
    name = prefs.getString('username');

    pass = prefs.getString('password');
  } else {
    prefs.setBool('remember', false);
    remember = false;
    name = '';
    pass = '';
  }
  _name.text = name;
  _pass.text = pass;
}

class LoginForm extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _LoginForm();
  }
}

class _LoginForm extends State<LoginForm> {
  String _message = '';

  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();

  _register() {
    _firebaseMessaging.getToken().then((token) => print(token));
  }

  // String name;
  // String password;
  bool valid = false;
  bool filled = false;
  bool indicator = false;
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  Future login(String userid, String password) async {
    String json = '{"userid":"' + userid + '","password":"' + password + '"}';
    print(json);
    String url = 'http://167.114.145.37:3000/Login';
    Map<String, String> headers = {
      // "Content-Type": "application/x-www-form-urlencoded"
      "Content-type": "application/json"
    };
    var response = await http.post(url, headers: headers, body: json);

    // var path='';
    print(response.body);
    if (response.body != '') {
      setState(() {
        // indicator=true;
        valid = false;
        var data = jsonDecode(response.body)[0];
        var path = data['Paath'];
        var line1 = data['line1'];
        var line2 = data['line2'];
        loginUser(userid, password, path, line1, line2);

        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) => SplashScreen(line1, line2)));
      });

      return 'done';
    } else {
      setState(() {
        // indicator=false;
        valid = true;
      });

      return '';
    }
  }

  @override
  void initState() {
    getMessage();
    setState(() {
      SharedPreferences.getInstance().then((SharedPreferences prefs) {
        print(prefs.getBool('remember'));
        remember = prefs.getBool('remember');
        if (remember == true) {
          //remember = true;
          name = prefs.getString('username');

          pass = prefs.getString('password');
        } else {
          prefs.setBool('remember', false);
          remember = false;
          name = '';
          pass = '';
        }
        _name.text = name;
        _pass.text = pass;
      });
    });

    super.initState();
  }

  void getMessage() {
    _firebaseMessaging.configure(
        onMessage: (Map<String, dynamic> message) async {
      print('on message $message');
      setState(() => _message = message["notification"]["title"]);
    }, onResume: (Map<String, dynamic> message) async {
      print('on resume $message');
      setState(() => _message = message["notification"]["title"]);
    }, onLaunch: (Map<String, dynamic> message) async {
      print('on launch $message');
      setState(() => _message = message["notification"]["title"]);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.teal,
        appBar: AppBar(
          title: Text('Login'),
        ),
        key: _scaffoldKey,
        body: Center(
          // child: FlareActor(
          //   'assets/switch_daytime.flr',
          //   animation: "day_idle",
          //   // fit: BoxFit.contain,
          //   //alignment: Alignment.center,
          // ),
          child: Padding(
              padding: EdgeInsets.all(10),
              child: SingleChildScrollView(
                  child: Card(
                      elevation: 20,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Icon(Icons.perm_identity,
                              size: 100, color: Colors.teal),
                          Padding(
                              padding: EdgeInsets.all(10),
                              child: Text(
                                'Login',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 20,
                                    color: Colors.teal),
                              )),
                          Padding(
                              padding: EdgeInsets.all(10),
                              child: TextFormField(
                                controller: _name,
                                //initialValue: name,
                                //obscureText: true,
                                onChanged: (String value) {
                                  setState(() {
                                    name = value;
                                    if (value.length > 0) {
                                      filled = false;
                                    }
                                  });
                                },
                                decoration: InputDecoration(
                                    enabledBorder: const OutlineInputBorder(
                                      borderSide: const BorderSide(
                                          color: Colors.teal, width: 0.0),
                                    ),
                                    focusedBorder: const OutlineInputBorder(
                                      borderSide: const BorderSide(
                                          color: Colors.teal, width: 0.0),
                                    ),
                                    labelText: 'Username',
                                    labelStyle: TextStyle(color: Colors.teal)),
                              )),
                          Padding(
                              padding: EdgeInsets.all(10),
                              child: TextFormField(
                                controller: _pass,
                                obscureText: true,
                                onChanged: (String value) {
                                  setState(() {
                                    pass = value;
                                    if (value.length > 0) {
                                      filled = false;
                                    }
                                  });
                                },
                                decoration: InputDecoration(
                                    enabledBorder: const OutlineInputBorder(
                                      borderSide: const BorderSide(
                                          color: Colors.teal, width: 0.0),
                                    ),
                                    focusedBorder: const OutlineInputBorder(
                                      borderSide: const BorderSide(
                                          color: Colors.teal, width: 0.0),
                                    ),
                                    labelText: 'Password',
                                    labelStyle: TextStyle(color: Colors.teal)),
                              )),
                          Row(
                            children: <Widget>[
                              Checkbox(
                                value: remember,
                                // tristate: true,
                                onChanged: (bool newValue) {
                                  setState(() {
                                    remember = newValue;
                                  });
                                },
                              ),
                              Text('Remember Me')
                            ],
                          ),
                          filled
                              ? Text('Please enter valid Data',
                                  style: TextStyle(color: Colors.red))
                              : Text(''),
                          valid
                              ? Text('Invalid Credentials',
                                  style: TextStyle(color: Colors.red))
                              : Text(''),
                          SizedBox(
                              width: double.infinity,
                              height: 80,
                              child: Padding(
                                  padding: EdgeInsets.all(10),
                                  child: RaisedButton(
                                    elevation: 15,
                                    color: Colors.white,
                                    child: Text('Submit',
                                        style: TextStyle(
                                          fontSize: 18,
                                          color: Colors.teal,
                                        )),
                                    onPressed: () {
                                      setState(() {
                                        if (name == '' || pass == '') {
                                          filled = true;
                                        } else {
                                          filled = false;
                                          _register();
                                          // login(_name.text, _pass.text);
                                          // print(path);

                                        }
                                      });

                                      // else{
                                      //   final snackBar = SnackBar(
                                      //     content: Text('Invalid Credentials'),
                                      //   );
                                      //   _scaffoldKey.currentState
                                      //       .showSnackBar(snackBar);
                                      // }
                                    },
                                  ))),

                          // indicator? Padding(padding: EdgeInsets.only(top: 30),child: Column(
                          //                   mainAxisAlignment:
                          //                       MainAxisAlignment.center,

                          //                   children: <Widget>[
                          //                     CircularProgressIndicator(
                          //                       backgroundColor: Colors.white,
                          //                     ),
                          //                     Padding(
                          //                       padding: EdgeInsets.only(top: 10),
                          //                     ),
                          //                     Text(
                          //                       'Loading...',
                          //                       style: TextStyle(color: Colors.teal),
                          //                     )
                          //                   ])):Text(''),
                        ],
                      )))),
        ));
  }
}

class RegisterForm extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _RegisterForm();
  }
}

class _RegisterForm extends State<RegisterForm> {
  String name;
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
          padding: EdgeInsets.all(10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(Icons.perm_identity, size: 100, color: Colors.teal),
              Padding(
                  padding: EdgeInsets.only(bottom: 10, top: 0),
                  child: Text(
                    'Register',
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        color: Colors.teal),
                  )),
              TextFormField(
                onChanged: (String value) {
                  setState(() {
                    name = value;
                  });
                },
                decoration: InputDecoration(
                    enabledBorder: const OutlineInputBorder(
                      borderSide:
                          const BorderSide(color: Colors.teal, width: 0.0),
                    ),
                    focusedBorder: const OutlineInputBorder(
                      borderSide:
                          const BorderSide(color: Colors.teal, width: 0.0),
                    ),
                    labelText: 'Username',
                    labelStyle: TextStyle(color: Colors.teal)),
              ),
              Padding(
                  padding: EdgeInsets.only(top: 10),
                  child: TextFormField(
                    onChanged: (String value) {
                      setState(() {
                        name = value;
                      });
                    },
                    decoration: InputDecoration(
                        enabledBorder: const OutlineInputBorder(
                          borderSide:
                              const BorderSide(color: Colors.teal, width: 0.0),
                        ),
                        focusedBorder: const OutlineInputBorder(
                          borderSide:
                              const BorderSide(color: Colors.teal, width: 0.0),
                        ),
                        labelText: 'Password',
                        labelStyle: TextStyle(color: Colors.teal)),
                  )),
              SizedBox(
                  width: double.infinity,
                  height: 80,
                  child: RaisedButton(
                    color: Colors.white,
                    child: Text('Submit',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.teal,
                        )),
                    onPressed: () {},
                  ))
            ],
          )),
    );
  }
}
