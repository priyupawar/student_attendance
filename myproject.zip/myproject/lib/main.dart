import 'package:flutter/material.dart';
import 'package:myproject/authform.dart';
//import 'package:animated_splash/animated_splash.dart';

// import 'package:myproject/getlist.dart';

void main() {
//SharedPreferences.setMockInitialValues({});
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: AuthForm(),
      theme: ThemeData(
          // platform: TargetPlatform.iOS,
          primaryColor: Colors.teal),
    );
  }
}
