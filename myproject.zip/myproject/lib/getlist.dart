//import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
//import 'package:json_table/table_column.dart';
//import 'package:http/http.dart' as http;
// import 'package:json_table/json_table.dart';
// import 'package:myproject/memberdetails.dart';

List jsonData;
List keys;
bool dataPresent;

class GetList extends StatefulWidget {
  final String details;
  final String name;
  GetList(this.details, this.name);
  @override
  State<StatefulWidget> createState() {
    return _GetList();
  }
}

class _GetList extends State<GetList> {
  int i;
  @override
  void initState() {
    jsonData = jsonDecode(widget.details);
    print(jsonData.length);
    if (jsonData.length > 0) {
      dataPresent = true;
      keys = jsonData[0].keys.toList();
    } else {
      dataPresent = false;
    }
    print(dataPresent);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(widget.name),
        ),
        //body:
        //Container(
        // height: screenHeight(context,dividedBy: 1),
        // padding: EdgeInsets.all(16.0),
        // child: Column(

        // children: [
        //   JsonTable(
        //     json,
        //     // showColumnToggle: true,
        //     tableHeaderBuilder: (String header) {
        //       return Container(
        //         padding:
        //             EdgeInsets.symmetric(horizontal: 10.0, vertical: 10.0),
        //         decoration: BoxDecoration(
        //             border: Border.all(width: 0.5), color: Colors.grey[300]),
        //         child: Text(
        //           header.toUpperCase(),
        //           textAlign: TextAlign.center,
        //           style: Theme.of(context).textTheme.display1.copyWith(
        //               fontWeight: FontWeight.w700,
        //               fontSize: 14.0,
        //               color: Colors.black87),
        //         ),
        //       );
        //     },

        //     tableCellBuilder: (value) {
        //       return
        //           // onTap: () {
        //           //   Navigator.push(
        //           //     context,
        //           //     MaterialPageRoute(
        //           //         builder: (context) => MemberDetails(value)),
        //           //   );
        //           // },
        //           Container(
        //             padding:
        //                 EdgeInsets.symmetric(horizontal: 7.0, vertical: 5.0),
        //             decoration: BoxDecoration(
        //                 border: Border.all(
        //                     width: 0.5, color: Colors.grey.withOpacity(0.5))),
        //             child: Text(
        //               value,
        //               textAlign: TextAlign.left,
        //               style: Theme.of(context)
        //                   .textTheme
        //                   .display1
        //                   .copyWith(fontSize: 14.0, color: Colors.grey[900]),
        //             ),
        //           );
        //     },
        //     allowRowHighlight: true,
        //     rowHighlightColor: Colors.yellow[500].withOpacity(0.7),
        //      paginationRowCount: 12,
        //   )
        // ],
        //    ),
        //  ),
        body: JsonTable());
  }
}

class JsonTable extends StatefulWidget {
  // final String details;
  // JsonTable(this.details);
  @override
  State<StatefulWidget> createState() {
    return _JsonTable();
  }
}

class _JsonTable extends State<JsonTable> {
  int i;
  List columns;

  DataRow _rowdetails(details) {
    List<DataCell> rows = [];
    int i;

    for (i = 0; i < keys.length; i++) {
      rows.add(DataCell(Text(details[keys[i]].toString())));
    }

    return DataRow(
      cells: rows,
    );
  }

  @override
  Widget build(BuildContext context) {
    return dataPresent
        ? SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                  columns: List.generate(keys.length,
                      (index) => DataColumn(label: Text(keys[index]))),
                  rows: List.generate(
                      jsonData.length, (index) => _rowdetails(jsonData[index])),
                )))
        : Text(
            'No Data Found',
            style: TextStyle(
              fontSize: 18,
            ),
          );
  }
}
