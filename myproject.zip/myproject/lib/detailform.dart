import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:myproject/getlist.dart';
import 'package:intl/intl.dart';
import 'package:myproject/sidenav.dart';
import 'package:shared_preferences/shared_preferences.dart';

String path;

class DetailForm extends StatefulWidget {
  final String name;
  final String id;
  DetailForm(this.name, this.id);
  @override
  State<StatefulWidget> createState() {
    return _DetailForm();
  }
}

class _DetailForm extends State<DetailForm> {
  bool checked1 = false;
  bool checked2 = false;
  bool indicator = false;
  String name1 = '';
  String name2 = '';
  bool fromPresent = false;
  bool toPresent = false;
  bool combo1Present = false;
  bool combo2Present = false;
  bool check1Present = false;
  bool check2Present = false;
  DateTime selecteddate = new DateTime.now();
  DateTime selecteddate2 = new DateTime.now();
  DateTime date = new DateTime.now();
  List<Map> data1;
  List comboData1;
  List comboData2;
  List keys1;
  List keys2;
  List reportDetails;
  String _date1;
  String _date2;
  String sp;

  Future selectDate1(BuildContext context) async {
    final DateTime picked = await showDatePicker(
      context: context,
      initialDate: selecteddate,
      firstDate: new DateTime(2000, 1, 1),
      lastDate: new DateTime(DateTime.now().year, 12, 31),
    );
    if (picked != null) {
      setState(() {
        selecteddate = picked;
        _date1 =
            DateFormat("dd-MMM-yy").format(DateTime.parse(picked.toString()));
      });
    }
  }

  Future selectDate2(BuildContext context) async {
    final DateTime picked2 = await showDatePicker(
      context: context,
      initialDate: selecteddate2,
      firstDate: new DateTime(2000, 1, 1),
      lastDate: new DateTime(DateTime.now().year, 12, 31),
    );
    if (picked2 != null) {
      setState(() {
        selecteddate2 = picked2;
        _date2 =
            DateFormat("dd-MMM-yy").format(DateTime.parse(picked2.toString()));
      });
    }
  }

  Future getReportDetails(String transID) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    path = prefs.getString('path');

    String json = '{"TransID":"' + transID + '"}';
    // print(path);
    String url = '' + path + '/GetReportDetails';
    Map<String, String> headers = {
      // "Content-Type": "application/x-www-form-urlencoded"
      "Content-type": "application/json"
    };
    var response = await http.post(url, headers: headers, body: json);
    setState(() {
      reportDetails = jsonDecode(response.body);
      // print(reportDetails);
      sp = reportDetails[0]['SP_NAME'];
      if (reportDetails[0]['CBO_1'] != null) {
        setState(() {
          getComboData1(reportDetails[0]['CBO_1_QRY']);
        });
      }
      // if (reportDetails[0]['CBO_2'] != null) {

      //   setState(() {

      //     getComboData2(reportDetails[0]['CBO_2_QRY']);

      //   });

      // }
      if (reportDetails[0]['CHK_BOX'] != null) {
        check1Present = true;
      }
      if (reportDetails[0]['CHK_BOX2'] != null) {
        check2Present = true;
      }
      if (reportDetails[0]['DTP_1'] != null) {
        fromPresent = true;
      }
      if (reportDetails[0]['DTP_2'] != null) {
        toPresent = true;
      }
      if (reportDetails[0]['CHK_BOX'] != null) {
        checked1 = true;
      }
      if (reportDetails[0]['CHK_BOX2'] != null) {
        checked2 = true;
      }

      // print('report data' + reportDetails.toString());
    });

    // Navigator.push(context,MaterialPageRoute(builder: (context) => ReportList(response.body)),);
  }

  Future getComboData1(String transID) async {
    String json = '{"condition":"' + transID + '","condition2":"0"}';
    String url = '' + path + '/GetComboData';
    Map<String, String> headers = {
      // "Content-Type": "application/x-www-form-urlencoded"
      "Content-type": "application/json"
    };
    var response = await http.post(url, headers: headers, body: json);
    setState(() {
      comboData1 = jsonDecode(response.body);
      //var i;
      // for(i=0;i<comboData1[0].keys.toList().length-1;i++){
      //   //keys1.add(comboData1[0].keys.toList()[i]);
      //   print(i);
      // }
      // print(comboData1);
      keys1 = comboData1[0].keys.toList();
      name1 = comboData1[0][keys1[0]].toString();
      combo1Present = true;
    });

    // Navigator.push(context,MaterialPageRoute(builder: (context) => ReportList(response.body)),);
  }

  Future getComboData2(String transID, String name) async {
    //print(transID);
    String json = '{"condition":"' + transID + '","condition2":"' + name + '"}';
    String url = '' + path + '/GetComboData';
    Map<String, String> headers = {
      // "Content-Type": "application/x-www-form-urlencoded"
      "Content-type": "application/json"
    };
    var response = await http.post(url, headers: headers, body: json);
    //print(response.body);
    setState(() {
      if (response.body != '') {
        comboData2 = jsonDecode(response.body);
        keys2 = comboData2[0].keys.toList();
        name2 = comboData2[0][keys2[1]].toString();
        combo2Present = true;
      }
    });

    // Navigator.push(context,MaterialPageRoute(builder: (context) => ReportList(response.body)),);
  }

  Future getEmpData(String name1, String name2, bool checked1, bool checked2,
      String date1, String date2, String sp) async {
    //String json = '{"AttId":"'+name+'","All":"'+checked.toString()+'","Date":"'+date+'","ClassName":"Teacher","AttType":"Staff"}';
    print(path);
    // if(!fromPresent){
    //   date1='null';
    // }
    // if(!toPresent){
    //   date2='null';
    // }
    String json = '{"combo1":"' +
        name1 +
        '","combo1All":"' +
        checked1.toString() +
        '","combo2":"' +
        name2 +
        '","combo2All":"' +
        checked2.toString() +
        '","FromDate":"' +
        date1 +
        '","ToDate":"' +
        date2 +
        '","SP_NAME":"' +
        sp +
        '"}';

    String url = '' + path + '/GetReportData';

    Map<String, String> headers = {
      // "Content-Type": "application/x-www-form-urlencoded"
      "Content-type": "application/json"
    };
    print(json);
    var response = await http.post(url, headers: headers, body: json);
    print(response.body);
    if (response.body != '') {
      indicator = false;
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => GetList(response.body, widget.name)),
      );
    }
  }

  @override
  void initState() {
    super.initState();

    getReportDetails(widget.id);
    _date1 = DateFormat("dd-MMM-yy").format(DateTime.parse(date.toString()));
    _date2 =
        DateFormat("dd-MMM-yy").format(DateTime.parse(selecteddate.toString()));
  }

  @override
  Widget build(BuildContext context) {
    if (combo1Present) {
      return Scaffold(
          appBar: AppBar(
            title: Text(widget.name),
          ),
          drawer: SideNav(),
          body: SingleChildScrollView(
              child: Padding(
                  padding: const EdgeInsets.only(bottom: 16.0),
                  child: Wrap(
                    children: <Widget>[
                      combo1Present
                          ? Column(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Container(
                                  margin: EdgeInsets.all(10.0),
                                  alignment: Alignment.topLeft,
                                  child: Padding(
                                    padding: EdgeInsets.only(right: 5),
                                    child: Text(
                                      reportDetails[0]['CBO_1'].toString(),
                                      style: TextStyle(
                                          color: Colors.teal,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 18.0),
                                    ),
                                  ),
                                ),
                                Row(
                                  children: <Widget>[
                                    check1Present
                                        ? Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: <Widget>[
                                                Checkbox(
                                                  value: checked1,
                                                  onChanged: (bool newValue) {
                                                    setState(() {
                                                      checked1 = newValue;

                                                      if (!newValue) {
                                                        getComboData2(
                                                            reportDetails[0][
                                                                    'CBO_2_QRY']
                                                                .toString(),
                                                            name1);
                                                      }
                                                    });
                                                  },
                                                ),
                                              ])
                                        : Text(''),
                                    combo1()
                                  ],
                                ),
                              ],
                            )
                          : Text(''),
                      !checked1
                          ? Column(
                              //crossAxisAlignment: CrossAxisAlignment.stretch,
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                combo2Present
                                    ? Container(
                                        margin: EdgeInsets.all(10.0),
                                        alignment: Alignment.centerLeft,
                                        //height: 80.0,
                                        child: Text(
                                          reportDetails[0]['CBO_2'].toString(),
                                          style: TextStyle(
                                              color: Colors.teal,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18.0),
                                        ),
                                      )
                                    : Text(''),
                                // Container(
                                //   margin: EdgeInsets.all(10.0),
                                //   child:
                                // ),

                                combo2Present
                                    ? Row(
                                        children: <Widget>[
                                          check2Present
                                              ? Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: <Widget>[
                                                      Checkbox(
                                                        value: checked2,
                                                        onChanged:
                                                            (bool newValue) {
                                                          setState(() {
                                                            checked2 = newValue;
                                                          });
                                                        },
                                                      ),
                                                    ])
                                              : Text(''),
                                          combo2(),
                                        ],
                                      )
                                    : Text('')
                              ],
                            )
                          : Text(''),
                      Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          fromPresent
                              ? Padding(
                                  padding: EdgeInsets.only(top: 10),
                                  child: RaisedButton(
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(5.0)),
                                    elevation: 6.0,
                                    onPressed: () {
                                      selectDate1(context);
                                      // DatePicker.showDatePicker(context,
                                      //     theme: DatePickerTheme(
                                      //       containerHeight: 210.0,
                                      //     ),
                                      //     showTitleActions: true,
                                      //     minTime: DateTime(2000, 1, 1),
                                      //     maxTime: DateTime(
                                      //         DateTime.now().year, 12, 31),
                                      //     onConfirm: (date) {
                                      //   // print('confirm $date');

                                      //   _date1 = DateFormat("dd-MMM-yy")
                                      //       .format(
                                      //           DateTime.parse(date.toString()))
                                      //       .toString();
                                      //   setState(() {});
                                      // },
                                      //     currentTime: DateTime.now(),
                                      //     locale: LocaleType.en);
                                    },
                                    child: Container(
                                      alignment: Alignment.center,
                                      height: 80.0,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: <Widget>[
                                          Row(
                                            children: <Widget>[
                                              Container(
                                                child: Row(
                                                  children: <Widget>[
                                                    Text(
                                                      reportDetails[0]['DTP_1']
                                                          .toString(),
                                                      style: TextStyle(
                                                          color: Colors.teal,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 18.0),
                                                    ),
                                                    Text(
                                                      " $_date1",
                                                      style: TextStyle(
                                                          color: Colors.teal,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 18.0),
                                                    ),
                                                  ],
                                                ),
                                              )
                                            ],
                                          ),
                                          Text(
                                            "  Change",
                                            style: TextStyle(
                                                color: Colors.teal,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 18.0),
                                          ),
                                        ],
                                      ),
                                    ),
                                    color: Colors.white,
                                  ))
                              : Text(''),
                          toPresent
                              ? Padding(
                                  padding: EdgeInsets.only(top: 10),
                                  child: RaisedButton(
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(5.0)),
                                    elevation: 6.0,
                                    onPressed: () {
                                      selectDate2(context);
                                      // DatePicker.showDatePicker(context,
                                      //     theme: DatePickerTheme(
                                      //       containerHeight: 210.0,
                                      //     ),
                                      //     showTitleActions: true,
                                      //     minTime: DateTime(2000, 1, 1),
                                      //     maxTime: DateTime(
                                      //         DateTime.now().year, 12, 31),
                                      //     onConfirm: (date) {
                                      //   //print('confirm $date');

                                      //   _date2 = DateFormat("dd-MMM-yy")
                                      //       .format(
                                      //           DateTime.parse(date.toString()))
                                      //       .toString();
                                      //   setState(() {});
                                      // },
                                      //     currentTime: DateTime.now(),
                                      //     locale: LocaleType.en);
                                    },
                                    child: Container(
                                      alignment: Alignment.center,
                                      height: 80.0,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: <Widget>[
                                          Row(
                                            children: <Widget>[
                                              Container(
                                                child: Row(
                                                  children: <Widget>[
                                                    Text(
                                                      reportDetails[0]['DTP_2']
                                                          .toString(),
                                                      style: TextStyle(
                                                          color: Colors.teal,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 18.0),
                                                    ),
                                                    Text(
                                                      " $_date2",
                                                      style: TextStyle(
                                                          color: Colors.teal,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 18.0),
                                                    ),
                                                  ],
                                                ),
                                              )
                                            ],
                                          ),
                                          Text(
                                            "  Change",
                                            style: TextStyle(
                                                color: Colors.teal,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 18.0),
                                          ),
                                        ],
                                      ),
                                    ),
                                    color: Colors.white,
                                  ))
                              : Text(''),
                        ],
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      Center(
                          child: Padding(
                              padding: EdgeInsets.only(top: 10.0),
                              child: SizedBox(
                                  width: double.infinity,
                                  height: 80,
                                  child: RaisedButton(
                                    color: Colors.white,
                                    onPressed: () {
                                      setState(() {
                                        indicator = true;
                                        getEmpData(name1, name2, checked1,
                                            checked2, _date1, _date2, sp);
                                      });
                                    },
                                    child: Text(
                                      "Submit",
                                      style: TextStyle(
                                          color: Colors.teal,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 18.0),
                                    ),
                                  )))),
                      indicator
                          ? Center(
                              child: Padding(
                                  padding: EdgeInsets.all(20),
                                  child: CircularProgressIndicator()))
                          : Text(''),
                    ],
                  ))));
    } else {
      return Scaffold(
          appBar: AppBar(
            title: Text(widget.name),
          ),
          body: new Center(
            child: new CircularProgressIndicator(),
          ));
    }
  }

  Widget combo1() {
    if (comboData1 != null) {
      return DropdownButton<String>(
        hint: Text(
            comboData1[0][keys1[1]].toString()), // Not necessary for Option 1
        // value: dropText,
        elevation: 16,
        style: TextStyle(color: Colors.deepPurple),
        items: !checked1
            ? comboData1.map((value) {
                return DropdownMenuItem<String>(
                  value: value[keys1[0]].toString(),
                  child: Text(value[keys1[1]]),
                );
              }).toList()
            : null,
        onChanged: (String newValue1) {
          setState(() {
            name1 = newValue1;

            getComboData2(reportDetails[0]['CBO_2_QRY'].toString(), name1);
          });
        },
        value: name1,
      );
    } else {
      return DropdownButton<String>(
        onChanged: (value) {},
        hint: Text(''), // Not necessary for Option 1
        // value: dropText,
        elevation: 16,
        style: TextStyle(color: Colors.deepPurple), items: null,
      );
    }
  }

  Widget combo2() {
    if (comboData2 != null) {
      return DropdownButton<String>(
        hint: Text(
            comboData2[0][keys2[1]].toString()), // Not necessary for Option 1
        // value: dropText,
        elevation: 16,
        style: TextStyle(color: Colors.deepPurple),
        items: !checked2
            ? comboData2.map((value) {
                return DropdownMenuItem<String>(
                  value: value[keys2[0]].toString(),
                  child: Text(value[keys2[1]]),
                );
              }).toList()
            : null,
        onChanged: (String newValue) {
          setState(() {
            name2 = newValue;
          });
        },
        value: name2,
      );
    } else {
      return DropdownButton<String>(
          items: null,
          onChanged: (value) {},
          hint: Text(''), // Not necessary for Option 1
          // value: dropText,
          elevation: 16,
          style: TextStyle(color: Colors.deepPurple));
    }
  }
}
